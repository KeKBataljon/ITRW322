package com.nqr.smsapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;


/**
 * Created by rushd on 25/10/2016.
 */

public class MMSBroadcastReceiver extends BroadcastReceiver {



    @Override
    public void onReceive(Context context, Intent intent) {

        throw new UnsupportedOperationException("Not yet Supported!");



    }
}